# Maths Chatbot

This is a simple chatbot made using Vanilla HTML, SCSS and JS. Type an expression such as 1 + 1 and then the bot will answer back with the answer!

## Tools

- HTML
- SCSS
- CSS
- JS

## License 

MIT
